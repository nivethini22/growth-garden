import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";

interface Message {
  id: number;
  text: string;
  isUser: boolean;
}

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, text: "Hi there! 🌱 I'm your Growth Garden assistant. How can I help you today? You can also type a page name to navigate there!", isUser: false }
  ]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const navigationPages: Record<string, string> = {
    "home": "/dashboard",
    "dashboard": "/dashboard",
    "welcome": "/",
    "mood": "/mood-tracker",
    "mood tracker": "/mood-tracker",
    "garden": "/garden",
    "calm": "/calm-session",
    "calm session": "/calm-session",
    "calming": "/calm-session",
    "emergency": "/emergency-contacts",
    "emergency contacts": "/emergency-contacts",
    "contacts": "/emergency-contacts",
    "login": "/login",
    "signin": "/login",
    "sign in": "/login",
    "signup": "/signup",
    "sign up": "/signup",
    "register": "/signup",
    "self-help": "/self-help",
    "selfhelp": "/self-help",
    "self help": "/self-help",
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now(),
      text: input,
      isUser: true,
    };
    setMessages(prev => [...prev, userMessage]);

    const lowerInput = input.toLowerCase().trim();
    let response = "";
    let shouldNavigate = false;
    let targetPath = "";

    // Check for navigation commands
    for (const [keyword, path] of Object.entries(navigationPages)) {
      if (lowerInput.includes(keyword)) {
        response = `Taking you to ${keyword}! 🌿`;
        shouldNavigate = true;
        targetPath = path;
        break;
      }
    }

    if (!shouldNavigate) {
      // Default helpful responses
      const responses = [
        "I'm here to support you on your mental wellness journey! 🌸",
        "Remember, every day is a chance for growth! 🌱",
        "You're doing amazing! Take things one step at a time. 💚",
        "Would you like to try a calming session? Type 'calm session' to go there!",
        "Tracking your mood can help you understand your patterns. Type 'mood tracker' to get started!",
        "Your garden grows with each positive step you take! Type 'garden' to see it!",
        "Need some guidance? Type 'self-help' to explore helpful resources!",
      ];
      response = responses[Math.floor(Math.random() * responses.length)];
    }

    setTimeout(() => {
      const botMessage: Message = {
        id: Date.now() + 1,
        text: response,
        isUser: false,
      };
      setMessages(prev => [...prev, botMessage]);

      if (shouldNavigate) {
        setTimeout(() => {
          setIsOpen(false);
          setIsMaximized(false);
          navigate(targetPath);
        }, 1000);
      }
    }, 500);

    setInput("");
  };

  const panelClasses = isMaximized
    ? "fixed inset-4 z-50 bg-card rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-primary/20"
    : "fixed bottom-24 right-6 z-50 w-80 h-96 bg-card rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-primary/20";

  return (
    <>
      {/* Chatbot Toggle Button */}
      <motion.button
        className="fixed bottom-6 right-6 z-50 bg-primary text-primary-foreground rounded-2xl px-4 py-3 shadow-lg flex items-center gap-2"
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        onClick={() => setIsOpen(!isOpen)}
        animate={{
          scale: isHovered ? 1.1 : 1,
        }}
        transition={{ duration: 0.2 }}
      >
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-6 h-6"
        >
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          <circle cx="9" cy="10" r="1" fill="currentColor" />
          <circle cx="15" cy="10" r="1" fill="currentColor" />
        </svg>
      </motion.button>

      {/* Chatbot Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className={panelClasses}
          >
            {/* Header */}
            <div className="bg-primary text-primary-foreground p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xl">🌱</span>
                <span className="font-semibold">Garden Assistant</span>
              </div>
              <div className="flex items-center gap-3">
                {/* Maximize/Minimize button */}
                <button
                  onClick={() => setIsMaximized(!isMaximized)}
                  className="hover:bg-primary-foreground/20 rounded-full p-1.5 transition-colors"
                  aria-label={isMaximized ? "Minimize" : "Maximize"}
                >
                  {isMaximized ? (
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3" />
                    </svg>
                  ) : (
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" />
                    </svg>
                  )}
                </button>
                {/* Close button */}
                <button
                  onClick={() => {
                    setIsOpen(false);
                    setIsMaximized(false);
                  }}
                  className="hover:bg-primary-foreground/20 rounded-full p-1.5 transition-colors"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M18 6L6 18M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${message.isUser ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                      message.isUser
                        ? "bg-primary text-primary-foreground rounded-br-md"
                        : "bg-secondary text-secondary-foreground rounded-bl-md"
                    }`}
                  >
                    {message.text}
                  </div>
                </motion.div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-3 border-t border-border">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  placeholder="What's on your mind?"
                  className="flex-1 bg-input rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
                <button
                  onClick={handleSend}
                  className="bg-primary text-primary-foreground rounded-xl px-4 py-2 hover:bg-primary/90 transition-colors"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />
                  </svg>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Chatbot;
