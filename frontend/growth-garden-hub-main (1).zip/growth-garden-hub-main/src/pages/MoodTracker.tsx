import { useState } from "react";
import { motion } from "framer-motion";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import Chatbot from "@/components/Chatbot";
import HomeButton from "@/components/HomeButton";
import MuteButton from "@/components/MuteButton";
import useKeyboardNavigation from "@/hooks/useKeyboardNavigation";

const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const emojis = ["😊", "😢", "😴", "😤", "🥰", "😌", "😰"];

interface MoodEntry {
  day: string;
  emoji: string | null;
}

const MoodTracker = () => {
  const [moodData, setMoodData] = useState<MoodEntry[]>(
    days.map(day => ({ day, emoji: null }))
  );
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  useKeyboardNavigation();

  const handleEmojiSelect = (emoji: string) => {
    if (!selectedDay) return;
    setMoodData(prev => 
      prev.map(entry => 
        entry.day === selectedDay ? { ...entry, emoji } : entry
      )
    );
    setSelectedDay(null);
  };

  // Mood score mapping - positive moods are higher, negative moods are lower
  const getMoodScore = (emoji: string | null): number | null => {
    if (!emoji) return null;
    const scores: Record<string, number> = {
      "🥰": 10,  // Love - highest positive
      "😊": 8,   // Happy - positive
      "😌": 7,   // Relaxed - positive
      "😴": 5,   // Tired - neutral
      "😤": 3,   // Frustrated - negative
      "😢": 2,   // Sad - negative
      "😰": 1,   // Anxious - lowest negative
    };
    return scores[emoji] ?? 5;
  };

  // Prepare data for line chart
  const chartData = moodData.map(entry => ({
    name: entry.day.slice(0, 3),
    score: getMoodScore(entry.emoji),
    emoji: entry.emoji,
  }));

  return (
    <div className="min-h-screen bg-garden-bg p-6 overflow-auto">
      <Chatbot />
      <HomeButton />
      <MuteButton />
      
      <motion.div
        className="max-w-4xl mx-auto pt-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-card-foreground mb-2 text-center">
          Mood Tracker 🌻
        </h1>
        <p className="text-muted-foreground text-center mb-8">
          Your mood over the past 7 days
        </p>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Daily Mood Selection */}
          <motion.div
            className="bg-card rounded-3xl p-6 shadow-lg"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
          >
            <h2 className="text-xl font-semibold text-card-foreground mb-4">
              Select your mood
            </h2>
            
            <div className="space-y-3">
              {moodData.map((entry, index) => (
                <motion.button
                  key={entry.day}
                  onClick={() => setSelectedDay(entry.day)}
                  className={`w-full flex items-center justify-between p-4 rounded-xl transition-all ${
                    selectedDay === entry.day 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-secondary hover:bg-secondary/80 text-secondary-foreground"
                  }`}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <span className="font-medium">{entry.day}</span>
                  <span className="text-2xl">{entry.emoji || "—"}</span>
                </motion.button>
              ))}
            </div>

            {/* Emoji Picker */}
            {selectedDay && (
              <motion.div
                className="mt-6 p-4 bg-background/50 rounded-xl"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
              >
                <p className="text-sm text-muted-foreground mb-3">
                  How are you feeling on {selectedDay}?
                </p>
                <div className="flex gap-2 flex-wrap justify-center">
                  {emojis.map(emoji => (
                    <motion.button
                      key={emoji}
                      onClick={() => handleEmojiSelect(emoji)}
                      className="text-3xl p-2 hover:bg-primary/20 rounded-lg transition-colors"
                      whileHover={{ scale: 1.2 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      {emoji}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}
          </motion.div>

          {/* Mood Graph - Line Chart */}
          <motion.div
            className="bg-card rounded-3xl p-6 shadow-lg"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            <h2 className="text-xl font-semibold text-card-foreground mb-4">
              Mood Graph
            </h2>
            
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 20, right: 20, bottom: 20, left: 0 }}>
                  <XAxis 
                    dataKey="name" 
                    stroke="hsl(117 17% 41%)"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis 
                    domain={[0, 10]} 
                    hide 
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-card p-2 rounded-lg shadow-lg border border-primary/20">
                            <p className="text-card-foreground font-medium">{data.name}</p>
                            <p className="text-2xl">{data.emoji || "—"}</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="hsl(117 25% 45%)"
                    strokeWidth={3}
                    dot={{ fill: "hsl(117 25% 45%)", strokeWidth: 2, r: 6 }}
                    activeDot={{ r: 8, fill: "hsl(117 25% 35%)" }}
                    connectNulls={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Legend */}
            <div className="mt-4 flex justify-between text-xs text-muted-foreground">
              <span>😰 Negative</span>
              <span>😴 Neutral</span>
              <span>🥰 Positive</span>
            </div>

            <div className="mt-4 text-center">
              <p className="text-sm text-muted-foreground">
                Click on a day to log your mood
              </p>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
};

export default MoodTracker;