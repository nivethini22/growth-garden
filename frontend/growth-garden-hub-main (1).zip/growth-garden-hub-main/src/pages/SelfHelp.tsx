import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Chatbot from "@/components/Chatbot";
import HomeButton from "@/components/HomeButton";
import MuteButton from "@/components/MuteButton";
import useKeyboardNavigation from "@/hooks/useKeyboardNavigation";

const motivationalQuotes = [
  { text: "Believe you can and you're halfway there.", emoji: "✨" },
  { text: "Every day is a new beginning. Take a deep breath and start again.", emoji: "🌅" },
  { text: "You are stronger than you think, braver than you believe.", emoji: "💪" },
  { text: "Happiness is not something ready-made. It comes from your own actions.", emoji: "🌻" },
  { text: "The only way out is through. Keep going.", emoji: "🚀" },
  { text: "You don't have to be perfect to be amazing.", emoji: "🌟" },
  { text: "Small steps every day lead to big changes.", emoji: "🦋" },
  { text: "Be gentle with yourself. You're doing the best you can.", emoji: "💚" },
  { text: "Your mental health is a priority. Your happiness is essential.", emoji: "🧠" },
  { text: "It's okay to not be okay. Healing takes time.", emoji: "🌈" },
];

const SelfHelp = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(() => {
    // Get a random starting index on mount
    return Math.floor(Math.random() * motivationalQuotes.length);
  });
  
  useKeyboardNavigation();

  // Set a random quote on mount only (no cycling)
  useEffect(() => {
    setCurrentQuoteIndex(Math.floor(Math.random() * motivationalQuotes.length));
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      const googleSearchUrl = `https://www.google.com/search?q=${encodeURIComponent(
        searchQuery + " self help techniques coping mechanisms mental health"
      )}`;
      window.open(googleSearchUrl, "_blank");
    }
  };

  const currentQuote = motivationalQuotes[currentQuoteIndex];

  return (
    <div className="min-h-screen bg-garden-bg flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <Chatbot />
      <HomeButton />
      <MuteButton />
      
      {/* Background Quote - static, no cycling */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.12 }}
          transition={{ duration: 1 }}
          className="text-center px-8 max-w-4xl"
        >
          <span className="text-9xl mb-4 block">{currentQuote.emoji}</span>
          <p className="text-4xl md:text-5xl lg:text-6xl font-bold text-card-foreground leading-relaxed">
            {currentQuote.text}
          </p>
        </motion.div>
      </div>

      {/* Main Content */}
      <motion.div
        className="relative z-10 text-center max-w-2xl w-full"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-card-foreground mb-2">
          Self-Help Resources 📚
        </h1>
        <p className="text-muted-foreground mb-8">
          Search for articles, blogs, and techniques for your wellness journey
        </p>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="mb-12">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for self-help techniques, coping strategies..."
              className="w-full px-6 py-4 pl-14 rounded-2xl bg-card text-card-foreground border-2 border-primary/30 focus:border-primary focus:outline-none focus:ring-4 focus:ring-primary/20 text-lg shadow-lg transition-all"
            />
            <svg
              className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
            <button
              type="submit"
              className="absolute right-3 top-1/2 -translate-y-1/2 bg-primary text-primary-foreground px-6 py-2 rounded-xl font-semibold hover:bg-primary/90 transition-colors"
            >
              Search
            </button>
          </div>
        </form>

        {/* Suggested Searches */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <p className="text-muted-foreground mb-3">Popular searches:</p>
          <div className="flex flex-wrap justify-center gap-2">
            {[
              "anxiety relief",
              "mindfulness meditation",
              "stress management",
              "self care tips",
              "positive affirmations",
              "breathing exercises",
            ].map((term) => (
              <button
                key={term}
                onClick={() => {
                  setSearchQuery(term);
                  const googleSearchUrl = `https://www.google.com/search?q=${encodeURIComponent(
                    term + " self help mental health"
                  )}`;
                  window.open(googleSearchUrl, "_blank");
                }}
                className="px-4 py-2 bg-secondary text-secondary-foreground rounded-xl text-sm hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                {term}
              </button>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default SelfHelp;